"""
CS 4375: Project 1 - Multinomial Naive Bayes
Implementation for Bag of Words representation
Based on: http://nlp.stanford.edu/IR-book/pdf/13bayes.pdf (Figure 13.2)
"""

import numpy as np
import csv
from typing import Tuple


class MultinomialNaiveBayes:
    """
    Multinomial Naive Bayes classifier for text classification.
    Uses Bag of Words representation.
    """
    
    def __init__(self, alpha: float = 1.0):
        """
        Initialize Multinomial Naive Bayes.
        
        Args:
            alpha: Laplace smoothing parameter (default=1 for add-one smoothing)
        """
        self.alpha = alpha
        self.log_prior = None  # Log prior probabilities P(c)
        self.log_likelihood = None  # Log likelihood P(w|c)
        self.classes = None
        self.n_features = None
    
    def fit(self, X: np.ndarray, y: np.ndarray):
        """
        Train Multinomial Naive Bayes classifier.
        
        Args:
            X: Feature matrix (n_samples, n_features) - word counts
            y: Labels (n_samples,) - 0 or 1
        """
        n_samples, n_features = X.shape
        self.n_features = n_features
        self.classes = np.unique(y)
        n_classes = len(self.classes)
        
        # Initialize log prior and log likelihood arrays
        self.log_prior = np.zeros(n_classes)
        self.log_likelihood = np.zeros((n_classes, n_features))
        
        # Compute for each class
        for idx, c in enumerate(self.classes):
            # Get all documents in class c
            X_c = X[y == c]
            
            # Compute log prior: log P(c)
            self.log_prior[idx] = np.log(X_c.shape[0] / n_samples)
            
            # Compute log likelihood: log P(w|c)
            # Count total words in class c across all documents
            word_counts_c = np.sum(X_c, axis=0)  # Sum of each word across all docs in class c
            
            # Total word count in class c
            total_words_c = np.sum(word_counts_c)
            
            # Apply Laplace smoothing and compute log probability
            # P(w_i|c) = (count(w_i, c) + alpha) / (sum_w count(w, c) + alpha * |V|)
            numerator = word_counts_c + self.alpha
            denominator = total_words_c + self.alpha * n_features
            
            self.log_likelihood[idx, :] = np.log(numerator / denominator)
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict class labels for samples.
        
        Args:
            X: Feature matrix (n_samples, n_features)
        
        Returns:
            Predicted class labels
        """
        # Compute log probabilities for each class
        log_probs = self._compute_log_probabilities(X)
        
        # Return class with highest log probability
        return self.classes[np.argmax(log_probs, axis=1)]
    
    def _compute_log_probabilities(self, X: np.ndarray) -> np.ndarray:
        """
        Compute log probabilities for each class.
        
        Args:
            X: Feature matrix (n_samples, n_features)
        
        Returns:
            Log probabilities array (n_samples, n_classes)
        """
        n_samples = X.shape[0]
        n_classes = len(self.classes)
        log_probs = np.zeros((n_samples, n_classes))
        
        for idx in range(n_classes):
            # For each document, compute:
            # log P(c) + sum_i (count(w_i) * log P(w_i|c))
            # Note: We stay in log space to avoid underflow
            log_probs[:, idx] = self.log_prior[idx] + np.dot(X, self.log_likelihood[idx, :])
        
        return log_probs
    
    def predict_log_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Predict log probabilities for each class.
        
        Args:
            X: Feature matrix (n_samples, n_features)
        
        Returns:
            Log probabilities (n_samples, n_classes)
        """
        return self._compute_log_probabilities(X)


def load_dataset(filepath: str) -> Tuple[np.ndarray, np.ndarray]:
    """
    Load dataset from CSV file.
    
    Args:
        filepath: Path to CSV file
    
    Returns:
        Tuple of (features, labels)
    """
    data = []
    labels = []
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)  # Skip header
        
        for row in reader:
            # Last column is label, rest are features
            features = [float(val) for val in row[:-1]]
            label = int(row[-1])
            data.append(features)
            labels.append(label)
    
    return np.array(data), np.array(labels)


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """
    Compute evaluation metrics.
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
    
    Returns:
        Dictionary with accuracy, precision, recall, F1 score
    """
    # True Positives, False Positives, True Negatives, False Negatives
    tp = np.sum((y_true == 1) & (y_pred == 1))
    fp = np.sum((y_true == 0) & (y_pred == 1))
    tn = np.sum((y_true == 0) & (y_pred == 0))
    fn = np.sum((y_true == 1) & (y_pred == 0))
    
    # Accuracy
    accuracy = (tp + tn) / (tp + fp + tn + fn)
    
    # Precision
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    
    # Recall
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    
    # F1 Score
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    
    return {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1
    }


if __name__ == "__main__":
    # Example usage
    print("CS 4375 Project 1 - Multinomial Naive Bayes")
    print("="*60)
    
    # Example: Load and train on a dataset
    # Uncomment and modify paths as needed
    """
    # Load BoW dataset
    X_train, y_train = load_dataset("processed_data/enron1_bow_train.csv")
    X_test, y_test = load_dataset("processed_data/enron1_bow_test.csv")
    
    # Train model
    print("\nTraining Multinomial Naive Bayes...")
    model = MultinomialNaiveBayes(alpha=1.0)
    model.fit(X_train, y_train)
    
    # Predict on test set
    y_pred = model.predict(X_test)
    
    # Compute metrics
    metrics = compute_metrics(y_test, y_pred)
    
    print("\nTest Results:")
    print(f"Accuracy:  {metrics['accuracy']:.4f}")
    print(f"Precision: {metrics['precision']:.4f}")
    print(f"Recall:    {metrics['recall']:.4f}")
    print(f"F1 Score:  {metrics['f1']:.4f}")
    """
