"""
CS 4375: Project 1 - Bernoulli Naive Bayes
Implementation for Bernoulli (binary) representation
"""

import numpy as np
import csv
from typing import Tuple


class BernoulliNaiveBayes:
    """
    Bernoulli Naive Bayes classifier for text classification.
    Uses binary (presence/absence) representation.
    """
    
    def __init__(self, alpha: float = 1.0):
        """
        Initialize Bernoulli Naive Bayes.
        
        Args:
            alpha: Laplace smoothing parameter (default=1 for add-one smoothing)
        """
        self.alpha = alpha
        self.log_prior = None  # Log prior probabilities P(c)
        self.log_prob_present = None  # Log P(w_i=1|c)
        self.log_prob_absent = None  # Log P(w_i=0|c)
        self.classes = None
        self.n_features = None
    
    def fit(self, X: np.ndarray, y: np.ndarray):
        """
        Train Bernoulli Naive Bayes classifier.
        
        Args:
            X: Feature matrix (n_samples, n_features) - binary values (0 or 1)
            y: Labels (n_samples,) - 0 or 1
        """
        n_samples, n_features = X.shape
        self.n_features = n_features
        self.classes = np.unique(y)
        n_classes = len(self.classes)
        
        # Initialize arrays
        self.log_prior = np.zeros(n_classes)
        self.log_prob_present = np.zeros((n_classes, n_features))
        self.log_prob_absent = np.zeros((n_classes, n_features))
        
        # Compute for each class
        for idx, c in enumerate(self.classes):
            # Get all documents in class c
            X_c = X[y == c]
            n_docs_c = X_c.shape[0]
            
            # Compute log prior: log P(c)
            self.log_prior[idx] = np.log(n_docs_c / n_samples)
            
            # For each feature, count how many documents in class c have it
            # Count documents where word appears (word=1)
            word_present_count = np.sum(X_c, axis=0)
            
            # Apply Laplace smoothing and compute probabilities
            # P(w_i=1|c) = (count(w_i=1, c) + alpha) / (N_c + 2*alpha)
            # P(w_i=0|c) = (count(w_i=0, c) + alpha) / (N_c + 2*alpha)
            #            = (N_c - count(w_i=1, c) + alpha) / (N_c + 2*alpha)
            
            numerator_present = word_present_count + self.alpha
            numerator_absent = (n_docs_c - word_present_count) + self.alpha
            denominator = n_docs_c + 2 * self.alpha
            
            self.log_prob_present[idx, :] = np.log(numerator_present / denominator)
            self.log_prob_absent[idx, :] = np.log(numerator_absent / denominator)
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict class labels for samples.
        
        Args:
            X: Feature matrix (n_samples, n_features) - binary values
        
        Returns:
            Predicted class labels
        """
        # Compute log probabilities for each class
        log_probs = self._compute_log_probabilities(X)
        
        # Return class with highest log probability
        return self.classes[np.argmax(log_probs, axis=1)]
    
    def _compute_log_probabilities(self, X: np.ndarray) -> np.ndarray:
        """
        Compute log probabilities for each class.
        
        Args:
            X: Feature matrix (n_samples, n_features)
        
        Returns:
            Log probabilities array (n_samples, n_classes)
        """
        n_samples = X.shape[0]
        n_classes = len(self.classes)
        log_probs = np.zeros((n_samples, n_classes))
        
        for idx in range(n_classes):
            # For each document and class, compute:
            # log P(c) + sum_i [x_i * log P(w_i=1|c) + (1-x_i) * log P(w_i=0|c)]
            # 
            # This can be vectorized as:
            # log P(c) + X * log P(w=1|c) + (1-X) * log P(w=0|c)
            
            # When word is present (x_i=1): add log P(w_i=1|c)
            # When word is absent (x_i=0): add log P(w_i=0|c)
            
            log_prob_class = self.log_prior[idx]
            
            # Vectorized computation
            for j in range(n_samples):
                log_prob_doc = 0.0
                for k in range(self.n_features):
                    if X[j, k] == 1:
                        log_prob_doc += self.log_prob_present[idx, k]
                    else:
                        log_prob_doc += self.log_prob_absent[idx, k]
                log_probs[j, idx] = log_prob_class + log_prob_doc
        
        return log_probs
    
    def predict_log_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Predict log probabilities for each class.
        
        Args:
            X: Feature matrix (n_samples, n_features)
        
        Returns:
            Log probabilities (n_samples, n_classes)
        """
        return self._compute_log_probabilities(X)


def load_dataset(filepath: str) -> Tuple[np.ndarray, np.ndarray]:
    """
    Load dataset from CSV file.
    
    Args:
        filepath: Path to CSV file
    
    Returns:
        Tuple of (features, labels)
    """
    data = []
    labels = []
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)  # Skip header
        
        for row in reader:
            # Last column is label, rest are features
            features = [float(val) for val in row[:-1]]
            label = int(row[-1])
            data.append(features)
            labels.append(label)
    
    return np.array(data), np.array(labels)


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """
    Compute evaluation metrics.
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
    
    Returns:
        Dictionary with accuracy, precision, recall, F1 score
    """
    # True Positives, False Positives, True Negatives, False Negatives
    tp = np.sum((y_true == 1) & (y_pred == 1))
    fp = np.sum((y_true == 0) & (y_pred == 1))
    tn = np.sum((y_true == 0) & (y_pred == 0))
    fn = np.sum((y_true == 1) & (y_pred == 0))
    
    # Accuracy
    accuracy = (tp + tn) / (tp + fp + tn + fn)
    
    # Precision
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    
    # Recall
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    
    # F1 Score
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    
    return {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1
    }


if __name__ == "__main__":
    # Example usage
    print("CS 4375 Project 1 - Bernoulli Naive Bayes")
    print("="*60)
    
    # Example: Load and train on a dataset
    # Uncomment and modify paths as needed
    """
    # Load Bernoulli dataset
    X_train, y_train = load_dataset("processed_data/enron1_bernoulli_train.csv")
    X_test, y_test = load_dataset("processed_data/enron1_bernoulli_test.csv")
    
    # Train model
    print("\nTraining Bernoulli Naive Bayes...")
    model = BernoulliNaiveBayes(alpha=1.0)
    model.fit(X_train, y_train)
    
    # Predict on test set
    y_pred = model.predict(X_test)
    
    # Compute metrics
    metrics = compute_metrics(y_test, y_pred)
    
    print("\nTest Results:")
    print(f"Accuracy:  {metrics['accuracy']:.4f}")
    print(f"Precision: {metrics['precision']:.4f}")
    print(f"Recall:    {metrics['recall']:.4f}")
    print(f"F1 Score:  {metrics['f1']:.4f}")
    """
