"""
CS 4375: Project 1 - Logistic Regression
Implementation of Logistic Regression with L2 regularization
Supports Batch GD, Mini-batch GD, and Stochastic GD
"""

import numpy as np
import csv
from typing import Tuple, List
import time


class LogisticRegression:
    """
    Logistic Regression classifier with L2 regularization.
    """
    
    def __init__(self, learning_rate: float = 0.01, lambda_reg: float = 1.0, 
                 max_iterations: int = 500, tolerance: float = 1e-6):
        """
        Initialize Logistic Regression model.
        
        Args:
            learning_rate: Learning rate for gradient descent
            lambda_reg: L2 regularization parameter
            max_iterations: Maximum number of iterations
            tolerance: Convergence tolerance
        """
        self.learning_rate = learning_rate
        self.lambda_reg = lambda_reg
        self.max_iterations = max_iterations
        self.tolerance = tolerance
        self.weights = None
        self.bias = None
        self.training_history = []
    
    def sigmoid(self, z: np.ndarray) -> np.ndarray:
        """
        Compute sigmoid function.
        
        Args:
            z: Input array
        
        Returns:
            Sigmoid of input
        """
        # Clip to prevent overflow
        z = np.clip(z, -500, 500)
        return 1 / (1 + np.exp(-z))
    
    def compute_loss(self, X: np.ndarray, y: np.ndarray) -> float:
        """
        Compute logistic loss with L2 regularization.
        
        Args:
            X: Feature matrix (n_samples, n_features)
            y: Labels (n_samples,)
        
        Returns:
            Loss value
        """
        m = X.shape[0]
        
        # Compute predictions
        z = np.dot(X, self.weights) + self.bias
        predictions = self.sigmoid(z)
        
        # Clip predictions to prevent log(0)
        predictions = np.clip(predictions, 1e-15, 1 - 1e-15)
        
        # Compute cross-entropy loss
        loss = -np.mean(y * np.log(predictions) + (1 - y) * np.log(1 - predictions))
        
        # Add L2 regularization (don't regularize bias)
        reg_term = (self.lambda_reg / (2 * m)) * np.sum(self.weights ** 2)
        
        return loss + reg_term
    
    def compute_gradients(self, X: np.ndarray, y: np.ndarray) -> Tuple[np.ndarray, float]:
        """
        Compute gradients for weights and bias.
        
        Args:
            X: Feature matrix (n_samples, n_features)
            y: Labels (n_samples,)
        
        Returns:
            Tuple of (weight_gradient, bias_gradient)
        """
        m = X.shape[0]
        
        # Compute predictions
        z = np.dot(X, self.weights) + self.bias
        predictions = self.sigmoid(z)
        
        # Compute error
        error = predictions - y
        
        # Compute gradients
        weight_gradient = (1 / m) * np.dot(X.T, error) + (self.lambda_reg / m) * self.weights
        bias_gradient = (1 / m) * np.sum(error)
        
        return weight_gradient, bias_gradient
    
    def fit_batch_gd(self, X: np.ndarray, y: np.ndarray, verbose: bool = False):
        """
        Train using Batch Gradient Descent.
        
        Args:
            X: Feature matrix (n_samples, n_features)
            y: Labels (n_samples,)
            verbose: Print training progress
        """
        n_samples, n_features = X.shape
        
        # Initialize weights and bias
        self.weights = np.zeros(n_features)
        self.bias = 0.0
        
        start_time = time.time()
        
        for iteration in range(self.max_iterations):
            # Compute gradients on entire dataset
            weight_grad, bias_grad = self.compute_gradients(X, y)
            
            # Update parameters
            self.weights -= self.learning_rate * weight_grad
            self.bias -= self.learning_rate * bias_grad
            
            # Compute loss
            loss = self.compute_loss(X, y)
            self.training_history.append(loss)
            
            if verbose and (iteration % 50 == 0 or iteration == self.max_iterations - 1):
                print(f"Iteration {iteration}: Loss = {loss:.6f}")
            
            # Check convergence
            if iteration > 0 and abs(self.training_history[-1] - self.training_history[-2]) < self.tolerance:
                if verbose:
                    print(f"Converged at iteration {iteration}")
                break
        
        training_time = time.time() - start_time
        if verbose:
            print(f"Training completed in {training_time:.2f} seconds")
    
    def fit_mini_batch_gd(self, X: np.ndarray, y: np.ndarray, batch_size: int = 50, 
                          verbose: bool = False):
        """
        Train using Mini-batch Gradient Descent.
        
        Args:
            X: Feature matrix (n_samples, n_features)
            y: Labels (n_samples,)
            batch_size: Size of mini-batches
            verbose: Print training progress
        """
        n_samples, n_features = X.shape
        
        # Initialize weights and bias
        self.weights = np.zeros(n_features)
        self.bias = 0.0
        
        start_time = time.time()
        
        for iteration in range(self.max_iterations):
            # Shuffle data
            indices = np.random.permutation(n_samples)
            X_shuffled = X[indices]
            y_shuffled = y[indices]
            
            # Process mini-batches
            for i in range(0, n_samples, batch_size):
                X_batch = X_shuffled[i:i+batch_size]
                y_batch = y_shuffled[i:i+batch_size]
                
                # Compute gradients on mini-batch
                weight_grad, bias_grad = self.compute_gradients(X_batch, y_batch)
                
                # Update parameters
                self.weights -= self.learning_rate * weight_grad
                self.bias -= self.learning_rate * bias_grad
            
            # Compute loss on full dataset
            loss = self.compute_loss(X, y)
            self.training_history.append(loss)
            
            if verbose and (iteration % 50 == 0 or iteration == self.max_iterations - 1):
                print(f"Iteration {iteration}: Loss = {loss:.6f}")
            
            # Check convergence
            if iteration > 0 and abs(self.training_history[-1] - self.training_history[-2]) < self.tolerance:
                if verbose:
                    print(f"Converged at iteration {iteration}")
                break
        
        training_time = time.time() - start_time
        if verbose:
            print(f"Training completed in {training_time:.2f} seconds")
    
    def fit_sgd(self, X: np.ndarray, y: np.ndarray, verbose: bool = False):
        """
        Train using Stochastic Gradient Descent (batch_size=1).
        
        Args:
            X: Feature matrix (n_samples, n_features)
            y: Labels (n_samples,)
            verbose: Print training progress
        """
        # SGD is just mini-batch GD with batch_size=1
        self.fit_mini_batch_gd(X, y, batch_size=1, verbose=verbose)
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Predict class probabilities.
        
        Args:
            X: Feature matrix (n_samples, n_features)
        
        Returns:
            Predicted probabilities for class 1
        """
        z = np.dot(X, self.weights) + self.bias
        return self.sigmoid(z)
    
    def predict(self, X: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        """
        Predict class labels.
        
        Args:
            X: Feature matrix (n_samples, n_features)
            threshold: Classification threshold
        
        Returns:
            Predicted labels (0 or 1)
        """
        probabilities = self.predict_proba(X)
        return (probabilities >= threshold).astype(int)


def load_dataset(filepath: str) -> Tuple[np.ndarray, np.ndarray]:
    """
    Load dataset from CSV file.
    
    Args:
        filepath: Path to CSV file
    
    Returns:
        Tuple of (features, labels)
    """
    data = []
    labels = []
    
    with open(filepath, 'r') as f:
        reader = csv.reader(f)
        header = next(reader)  # Skip header
        
        for row in reader:
            # Last column is label, rest are features
            features = [float(val) for val in row[:-1]]
            label = int(row[-1])
            data.append(features)
            labels.append(label)
    
    return np.array(data), np.array(labels)


def train_val_split(X: np.ndarray, y: np.ndarray, val_ratio: float = 0.3, 
                   random_seed: int = 42) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Split data into training and validation sets.
    
    Args:
        X: Feature matrix
        y: Labels
        val_ratio: Ratio of validation data
        random_seed: Random seed for reproducibility
    
    Returns:
        Tuple of (X_train, X_val, y_train, y_val)
    """
    np.random.seed(random_seed)
    n_samples = X.shape[0]
    indices = np.random.permutation(n_samples)
    
    val_size = int(n_samples * val_ratio)
    
    val_indices = indices[:val_size]
    train_indices = indices[val_size:]
    
    X_train = X[train_indices]
    X_val = X[val_indices]
    y_train = y[train_indices]
    y_val = y[val_indices]
    
    return X_train, X_val, y_train, y_val


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """
    Compute evaluation metrics.
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
    
    Returns:
        Dictionary with accuracy, precision, recall, F1 score
    """
    # True Positives, False Positives, True Negatives, False Negatives
    tp = np.sum((y_true == 1) & (y_pred == 1))
    fp = np.sum((y_true == 0) & (y_pred == 1))
    tn = np.sum((y_true == 0) & (y_pred == 0))
    fn = np.sum((y_true == 1) & (y_pred == 0))
    
    # Accuracy
    accuracy = (tp + tn) / (tp + fp + tn + fn)
    
    # Precision
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    
    # Recall
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    
    # F1 Score
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    
    return {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1
    }


def hyperparameter_tuning(X_train: np.ndarray, y_train: np.ndarray,
                         X_val: np.ndarray, y_val: np.ndarray,
                         lambda_values: List[float], gd_variant: str,
                         learning_rate: float = 0.01, batch_size: int = 50) -> float:
    """
    Tune lambda hyperparameter using validation set.
    
    Args:
        X_train: Training features
        y_train: Training labels
        X_val: Validation features
        y_val: Validation labels
        lambda_values: List of lambda values to try
        gd_variant: 'batch', 'mini_batch', or 'sgd'
        learning_rate: Learning rate
        batch_size: Batch size for mini-batch GD
    
    Returns:
        Best lambda value
    """
    best_lambda = lambda_values[0]
    best_f1 = 0.0
    
    print(f"\nTuning lambda for {gd_variant} GD...")
    
    for lambda_val in lambda_values:
        model = LogisticRegression(learning_rate=learning_rate, lambda_reg=lambda_val,
                                  max_iterations=500)
        
        # Train model
        if gd_variant == 'batch':
            model.fit_batch_gd(X_train, y_train, verbose=False)
        elif gd_variant == 'mini_batch':
            model.fit_mini_batch_gd(X_train, y_train, batch_size=batch_size, verbose=False)
        else:  # sgd
            model.fit_sgd(X_train, y_train, verbose=False)
        
        # Evaluate on validation set
        y_val_pred = model.predict(X_val)
        metrics = compute_metrics(y_val, y_val_pred)
        
        print(f"  λ={lambda_val:.2f}: F1={metrics['f1']:.4f}")
        
        if metrics['f1'] > best_f1:
            best_f1 = metrics['f1']
            best_lambda = lambda_val
    
    print(f"Best λ: {best_lambda} (F1={best_f1:.4f})")
    return best_lambda


if __name__ == "__main__":
    # Example usage
    print("CS 4375 Project 1 - Logistic Regression")
    print("="*60)
    
    # Example: Load and train on a dataset
    # Uncomment and modify paths as needed
    """
    X_train, y_train = load_dataset("processed_data/enron1_bow_train.csv")
    X_test, y_test = load_dataset("processed_data/enron1_bow_test.csv")
    
    # Split for validation
    X_tr, X_val, y_tr, y_val = train_val_split(X_train, y_train)
    
    # Tune hyperparameters
    lambda_values = [0.01, 0.1, 1.0, 10.0]
    best_lambda = hyperparameter_tuning(X_tr, y_tr, X_val, y_val, lambda_values, 'batch')
    
    # Train final model on full training set
    model = LogisticRegression(learning_rate=0.01, lambda_reg=best_lambda)
    model.fit_batch_gd(X_train, y_train, verbose=True)
    
    # Evaluate on test set
    y_pred = model.predict(X_test)
    metrics = compute_metrics(y_test, y_pred)
    print(f"\nTest Results:")
    print(f"Accuracy: {metrics['accuracy']:.4f}")
    print(f"Precision: {metrics['precision']:.4f}")
    print(f"Recall: {metrics['recall']:.4f}")
    print(f"F1 Score: {metrics['f1']:.4f}")
    """
