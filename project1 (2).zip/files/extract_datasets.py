"""
CS 4375 Project 1 - Dataset Extraction Script
Automatically extracts project_1.zip and organizes dataset folders
Works on Windows, Mac, and Linux
"""

import os
import zipfile
import shutil
from pathlib import Path


def extract_datasets():
    """Extract all dataset zip files and organize folders."""
    
    print("=" * 60)
    print("CS 4375 Project 1 - Dataset Extraction")
    print("=" * 60)
    print()
    
    # Get current directory
    current_dir = Path.cwd()
    print(f"Working directory: {current_dir}")
    print()
    
    # Step 1: Extract main project_1.zip if needed
    project_zip = current_dir / "project_1.zip"
    project_dir = current_dir / "project 1"
    
    if project_zip.exists():
        print("[1/3] Extracting project_1.zip...")
        try:
            with zipfile.ZipFile(project_zip, 'r') as zip_ref:
                zip_ref.extractall(current_dir)
            print("  ✓ Extracted project_1.zip")
        except Exception as e:
            print(f"  ✗ Error extracting project_1.zip: {e}")
            return False
    elif project_dir.exists():
        print("[1/3] project 1 folder already exists")
    else:
        print("✗ ERROR: Cannot find project_1.zip")
        print("  Please make sure project_1.zip is in the current directory")
        return False
    
    print()
    
    # Step 2: Extract individual dataset zips
    dataset_dir = project_dir / "dataset"
    
    if not dataset_dir.exists():
        print("✗ ERROR: Dataset folder not found at:", dataset_dir)
        return False
    
    print("[2/3] Extracting individual dataset zip files...")
    os.chdir(dataset_dir)
    
    zip_files = list(dataset_dir.glob("*.zip"))
    if not zip_files:
        print("  ℹ No zip files found - datasets may already be extracted")
    else:
        for zip_file in zip_files:
            print(f"  Extracting {zip_file.name}...")
            try:
                with zipfile.ZipFile(zip_file, 'r') as zip_ref:
                    zip_ref.extractall(dataset_dir)
            except Exception as e:
                print(f"  ✗ Error extracting {zip_file.name}: {e}")
    
    print()
    
    # Step 3: Organize folders
    print("[3/3] Organizing folders...")
    
    # Check for loose train/test folders (these belong to enron2)
    train_dir = dataset_dir / "train"
    test_dir = dataset_dir / "test"
    enron2_dir = dataset_dir / "enron2"
    
    if train_dir.exists() or test_dir.exists():
        print("  Found loose train/test folders - organizing into enron2...")
        
        if not enron2_dir.exists():
            enron2_dir.mkdir()
        
        if train_dir.exists():
            shutil.move(str(train_dir), str(enron2_dir / "train"))
            print("  ✓ Moved train folder to enron2")
        
        if test_dir.exists():
            shutil.move(str(test_dir), str(enron2_dir / "test"))
            print("  ✓ Moved test folder to enron2")
    
    print()
    
    # Step 4: Verify structure
    print("=" * 60)
    print("Extraction Complete!")
    print("=" * 60)
    print()
    print("Dataset folders found:")
    
    all_good = True
    for dataset_name in ["enron1", "enron2", "enron4"]:
        dataset_path = dataset_dir / dataset_name
        if dataset_path.exists():
            # Count files
            try:
                train_spam_count = len(list((dataset_path / "train" / "spam").glob("*.txt")))
                train_ham_count = len(list((dataset_path / "train" / "ham").glob("*.txt")))
                test_spam_count = len(list((dataset_path / "test" / "spam").glob("*.txt")))
                test_ham_count = len(list((dataset_path / "test" / "ham").glob("*.txt")))
                
                print(f"  ✓ {dataset_name}: Train({train_spam_count} spam, {train_ham_count} ham), "
                      f"Test({test_spam_count} spam, {test_ham_count} ham)")
            except Exception as e:
                print(f"  ⚠ {dataset_name}: Found but structure unclear - {e}")
        else:
            print(f"  ✗ {dataset_name}: NOT FOUND")
            all_good = False
    
    print()
    
    if all_good:
        print("=" * 60)
        print("SUCCESS! All datasets extracted and organized.")
        print("=" * 60)
        print()
        print("Next steps:")
        print("  1. Go back to your scripts directory:")
        print(f"     cd \"{current_dir}\"")
        print()
        print("  2. Run data preparation:")
        print(f"     python data_preparation.py \"{dataset_dir}\"")
        print()
        print("     OR let it auto-detect:")
        print("     python data_preparation.py")
        return True
    else:
        print("=" * 60)
        print("WARNING: Some datasets are missing or incomplete.")
        print("Please check the folder structure manually.")
        print("=" * 60)
        return False


if __name__ == "__main__":
    try:
        success = extract_datasets()
        if not success:
            print("\nPress Enter to exit...")
            input()
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        print("\nPress Enter to exit...")
        input()
