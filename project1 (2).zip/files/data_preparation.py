"""
CS 4375: Project 1 - Data Preparation
Converts raw email datasets into Bag of Words and Bernoulli representations
"""

import os
import re
import csv
from collections import Counter
from typing import List, Set, Tuple
import string

# Using NLTK for stopwords (standard library for text processing)
try:
    import nltk
    from nltk.corpus import stopwords
    nltk.download('stopwords', quiet=True)
    STOPWORDS = set(stopwords.words('english'))
except:
    # Fallback stopwords if NLTK is not available
    STOPWORDS = {
        'the', 'is', 'and', 'to', 'a', 'of', 'in', 'that', 'it', 'for', 
        'on', 'with', 'as', 'was', 'at', 'be', 'this', 'by', 'from', 'or',
        'an', 'are', 'which', 'but', 'not', 'have', 'has', 'had', 'they',
        'their', 'will', 'would', 'can', 'if', 'do', 'we', 'you', 'your'
    }


def preprocess_text(text: str) -> List[str]:
    """
    Preprocess text by converting to lowercase, removing punctuation, and tokenizing.
    
    Args:
        text: Raw email text
    
    Returns:
        List of preprocessed tokens (words)
    """
    # Convert to lowercase
    text = text.lower()
    
    # Remove punctuation using regex (keep only alphanumeric and spaces)
    text = re.sub(r'[^a-z0-9\s]', ' ', text)
    
    # Split into words
    words = text.split()
    
    # Remove stopwords and very short words (less than 2 characters)
    words = [word for word in words if word not in STOPWORDS and len(word) >= 2]
    
    return words


def read_email(filepath: str) -> str:
    """
    Read email content from file.
    
    Args:
        filepath: Path to email file
    
    Returns:
        Email content as string
    """
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return ""


def build_vocabulary(train_spam_dir: str, train_ham_dir: str) -> List[str]:
    """
    Build vocabulary from training data only.
    
    Args:
        train_spam_dir: Directory containing spam training emails
        train_ham_dir: Directory containing ham training emails
    
    Returns:
        Sorted list of unique words (vocabulary)
    """
    word_set = set()
    
    # Process spam emails
    for filename in os.listdir(train_spam_dir):
        filepath = os.path.join(train_spam_dir, filename)
        if os.path.isfile(filepath):
            text = read_email(filepath)
            words = preprocess_text(text)
            word_set.update(words)
    
    # Process ham emails
    for filename in os.listdir(train_ham_dir):
        filepath = os.path.join(train_ham_dir, filename)
        if os.path.isfile(filepath):
            text = read_email(filepath)
            words = preprocess_text(text)
            word_set.update(words)
    
    # Sort vocabulary for consistency
    vocabulary = sorted(list(word_set))
    
    print(f"Vocabulary size: {len(vocabulary)} words")
    return vocabulary


def email_to_bow_vector(email_text: str, vocabulary: List[str]) -> List[int]:
    """
    Convert email to Bag of Words vector.
    
    Args:
        email_text: Raw email text
        vocabulary: List of vocabulary words
    
    Returns:
        BoW vector (word counts)
    """
    words = preprocess_text(email_text)
    word_counts = Counter(words)
    
    # Create vector based on vocabulary
    vector = [word_counts.get(word, 0) for word in vocabulary]
    return vector


def email_to_bernoulli_vector(email_text: str, vocabulary: List[str]) -> List[int]:
    """
    Convert email to Bernoulli vector.
    
    Args:
        email_text: Raw email text
        vocabulary: List of vocabulary words
    
    Returns:
        Bernoulli vector (binary presence/absence)
    """
    words = preprocess_text(email_text)
    word_set = set(words)
    
    # Create binary vector based on vocabulary
    vector = [1 if word in word_set else 0 for word in vocabulary]
    return vector


def process_dataset(spam_dir: str, ham_dir: str, vocabulary: List[str], 
                   representation: str) -> Tuple[List[List[int]], List[int]]:
    """
    Process a dataset (train or test) into feature matrix and labels.
    
    Args:
        spam_dir: Directory containing spam emails
        ham_dir: Directory containing ham emails
        vocabulary: Vocabulary list
        representation: 'bow' or 'bernoulli'
    
    Returns:
        Tuple of (feature_matrix, labels)
    """
    feature_matrix = []
    labels = []
    
    # Process spam emails (label = 1)
    spam_files = sorted(os.listdir(spam_dir))
    for filename in spam_files:
        filepath = os.path.join(spam_dir, filename)
        if os.path.isfile(filepath):
            text = read_email(filepath)
            if representation == 'bow':
                vector = email_to_bow_vector(text, vocabulary)
            else:  # bernoulli
                vector = email_to_bernoulli_vector(text, vocabulary)
            feature_matrix.append(vector)
            labels.append(1)
    
    # Process ham emails (label = 0)
    ham_files = sorted(os.listdir(ham_dir))
    for filename in ham_files:
        filepath = os.path.join(ham_dir, filename)
        if os.path.isfile(filepath):
            text = read_email(filepath)
            if representation == 'bow':
                vector = email_to_bow_vector(text, vocabulary)
            else:  # bernoulli
                vector = email_to_bernoulli_vector(text, vocabulary)
            feature_matrix.append(vector)
            labels.append(0)
    
    print(f"Processed {len(labels)} emails ({sum(labels)} spam, {len(labels)-sum(labels)} ham)")
    return feature_matrix, labels


def save_to_csv(feature_matrix: List[List[int]], labels: List[int], 
                vocabulary: List[str], output_file: str):
    """
    Save feature matrix and labels to CSV file.
    
    Args:
        feature_matrix: Feature matrix (each row is an email)
        labels: Class labels (1=spam, 0=ham)
        vocabulary: Vocabulary list (for column names)
        output_file: Output CSV filename
    """
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        
        # Write header
        header = vocabulary + ['label']
        writer.writerow(header)
        
        # Write data rows
        for features, label in zip(feature_matrix, labels):
            row = features + [label]
            writer.writerow(row)
    
    print(f"Saved to {output_file}")


def process_all_datasets(base_dir: str, output_dir: str):
    """
    Process all three datasets (enron1, enron2, enron4) with both representations.
    
    Args:
        base_dir: Base directory containing the dataset folders
        output_dir: Output directory for CSV files
    """
    datasets = ['enron1', 'enron2', 'enron4']
    representations = ['bow', 'bernoulli']
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    for dataset in datasets:
        print(f"\n{'='*60}")
        print(f"Processing {dataset.upper()}")
        print(f"{'='*60}")
        
        # Define paths
        train_spam_dir = os.path.join(base_dir, dataset, 'train', 'spam')
        train_ham_dir = os.path.join(base_dir, dataset, 'train', 'ham')
        test_spam_dir = os.path.join(base_dir, dataset, 'test', 'spam')
        test_ham_dir = os.path.join(base_dir, dataset, 'test', 'ham')
        
        # Build vocabulary from training data only
        print("\nBuilding vocabulary from training data...")
        vocabulary = build_vocabulary(train_spam_dir, train_ham_dir)
        
        # Process both representations
        for representation in representations:
            print(f"\n--- {representation.upper()} Representation ---")
            
            # Process training set
            print("Processing training set...")
            train_features, train_labels = process_dataset(
                train_spam_dir, train_ham_dir, vocabulary, representation
            )
            train_output = os.path.join(output_dir, f"{dataset}_{representation}_train.csv")
            save_to_csv(train_features, train_labels, vocabulary, train_output)
            
            # Process test set
            print("Processing test set...")
            test_features, test_labels = process_dataset(
                test_spam_dir, test_ham_dir, vocabulary, representation
            )
            test_output = os.path.join(output_dir, f"{dataset}_{representation}_test.csv")
            save_to_csv(test_features, test_labels, vocabulary, test_output)


def find_dataset_directory() -> str:
    """
    Auto-detect where the enron dataset folders are located.
    Checks common locations relative to this script.
    
    Returns:
        Path to directory containing enron1, enron2, enron4
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Places to search for enron1/enron2/enron4
    candidate_bases = [
        script_dir,                          # same folder as script
        os.path.join(script_dir, "datasets"),
        os.path.join(script_dir, "data"),
        os.path.join(script_dir, "enron"),
        os.path.join(os.path.dirname(script_dir), "datasets"),
    ]
    
    for base in candidate_bases:
        if os.path.isdir(base):
            # Check if any of the expected dataset folders exist here
            for dataset in ["enron1", "enron2", "enron4"]:
                if os.path.isdir(os.path.join(base, dataset)):
                    print(f"  Found datasets at: {base}")
                    return base
    
    return None


def detect_folder_structure(dataset_dir: str) -> str:
    """
    Detect whether dataset uses train/test subfolders or flat spam/ham folders.
    
    Args:
        dataset_dir: Path to one dataset (e.g., .../enron1)
    
    Returns:
        'split'  -> enron1/train/spam, enron1/train/ham, enron1/test/spam, enron1/test/ham
        'flat'   -> enron1/spam, enron1/ham  (no train/test split)
    """
    if os.path.isdir(os.path.join(dataset_dir, "train")):
        return "split"
    elif os.path.isdir(os.path.join(dataset_dir, "spam")):
        return "flat"
    else:
        # Try to list what's inside
        try:
            contents = os.listdir(dataset_dir)
            print(f"  Contents of {dataset_dir}: {contents}")
        except:
            pass
        return "unknown"


def process_all_datasets_auto(base_dir: str, output_dir: str):
    """
    Process all datasets, auto-detecting folder structure.
    Handles both split (train/test) and flat (spam/ham only) layouts.
    """
    datasets = ['enron1', 'enron2', 'enron4']
    representations = ['bow', 'bernoulli']
    os.makedirs(output_dir, exist_ok=True)

    for dataset in datasets:
        dataset_path = os.path.join(base_dir, dataset)
        
        if not os.path.isdir(dataset_path):
            print(f"\n[WARNING] Could not find dataset folder: {dataset_path}")
            print(f"  Skipping {dataset}.")
            continue

        print(f"\n{'='*60}")
        print(f"Processing {dataset.upper()} at: {dataset_path}")
        print(f"{'='*60}")

        structure = detect_folder_structure(dataset_path)
        print(f"  Detected folder structure: '{structure}'")

        if structure == "split":
            train_spam_dir = os.path.join(dataset_path, "train", "spam")
            train_ham_dir  = os.path.join(dataset_path, "train", "ham")
            test_spam_dir  = os.path.join(dataset_path, "test",  "spam")
            test_ham_dir   = os.path.join(dataset_path, "test",  "ham")
        elif structure == "flat":
            # No train/test split — use all data as train, no separate test
            print("  [INFO] Flat structure detected: using all emails for training, no separate test set.")
            train_spam_dir = os.path.join(dataset_path, "spam")
            train_ham_dir  = os.path.join(dataset_path, "ham")
            test_spam_dir  = train_spam_dir   # same as train (no separate test)
            test_ham_dir   = train_ham_dir
        else:
            print(f"  [ERROR] Unknown structure in {dataset_path}. Skipping.")
            continue

        # Verify directories exist
        for d in [train_spam_dir, train_ham_dir, test_spam_dir, test_ham_dir]:
            if not os.path.isdir(d):
                print(f"  [ERROR] Directory not found: {d}")
                print(f"  Please check your folder structure and update the paths.")
                continue

        # Build vocabulary from training data only
        print("\nBuilding vocabulary from training data...")
        vocabulary = build_vocabulary(train_spam_dir, train_ham_dir)

        # Process both representations
        for representation in representations:
            print(f"\n--- {representation.upper()} Representation ---")

            print("Processing training set...")
            train_features, train_labels = process_dataset(
                train_spam_dir, train_ham_dir, vocabulary, representation
            )
            train_output = os.path.join(output_dir, f"{dataset}_{representation}_train.csv")
            save_to_csv(train_features, train_labels, vocabulary, train_output)

            print("Processing test set...")
            test_features, test_labels = process_dataset(
                test_spam_dir, test_ham_dir, vocabulary, representation
            )
            test_output = os.path.join(output_dir, f"{dataset}_{representation}_test.csv")
            save_to_csv(test_features, test_labels, vocabulary, test_output)


if __name__ == "__main__":
    import sys

    print("CS 4375 Project 1 - Data Preparation")
    print("Converting email datasets to CSV format...")
    print()

    # ── Allow user to pass path as command-line argument ──────────────────────
    # Usage:  python data_preparation.py [base_dir] [output_dir]
    # Example: python data_preparation.py C:\Users\me\Downloads\files .\processed_data
    if len(sys.argv) >= 2:
        base_directory = sys.argv[1]
    else:
        # Auto-detect
        print("Auto-detecting dataset location...")
        base_directory = find_dataset_directory()

    if len(sys.argv) >= 3:
        output_directory = sys.argv[2]
    else:
        # Place output next to this script
        output_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), "processed_data")

    if base_directory is None:
        print()
        print("ERROR: Could not find enron1/enron2/enron4 folders automatically.")
        print()
        print("Please run the script with the correct base path, for example:")
        print(r"  python data_preparation.py C:\Users\nidhi_santosh\Downloads\files")
        print()
        print("Or edit the 'base_directory' variable at the bottom of data_preparation.py")
        sys.exit(1)

    print(f"Dataset directory : {base_directory}")
    print(f"Output directory  : {output_directory}")
    print()

    process_all_datasets_auto(base_directory, output_directory)

    print("\n" + "="*60)
    print("Data preparation complete!")
    print(f"CSV files saved to: {output_directory}")
    print("="*60)
