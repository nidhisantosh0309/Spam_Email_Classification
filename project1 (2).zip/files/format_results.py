"""
CS 4375: Project 1 - Results Formatter
Utility to format experimental results into report tables
"""

import os


def format_lr_results_table(results_file: str):
    """
    Format Logistic Regression results into a nice table for the report.
    
    Args:
        results_file: Path to logistic regression results file
    """
    print("\n" + "="*100)
    print("LOGISTIC REGRESSION RESULTS TABLE")
    print("="*100)
    
    if not os.path.exists(results_file):
        print(f"Error: {results_file} not found")
        return
    
    with open(results_file, 'r', encoding='utf-8') as f:
        content = f.read()
        print(content)
    
    print("\nLaTeX Table Format:")
    print("-"*100)
    print(r"\begin{table}[h]")
    print(r"\centering")
    print(r"\caption{Logistic Regression Results}")
    print(r"\begin{tabular}{|l|l|l|c|c|c|c|c|}")
    print(r"\hline")
    print(r"Dataset & Repr. & GD Variant & Best Lambda & Accuracy & Precision & Recall & F1 \\")
    print(r"\hline")
    
    # Parse and format each result
    with open(results_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        for line in lines[3:]:  # Skip header lines
            if line.strip() and not line.startswith('-'):
                parts = line.split()
                if len(parts) >= 8:
                    dataset = parts[0]
                    repr_type = parts[1]
                    gd_variant = ' '.join(parts[2:-5])  # GD variant might be multi-word
                    best_lambda = parts[-5]
                    accuracy = parts[-4]
                    precision = parts[-3]
                    recall = parts[-2]
                    f1 = parts[-1]
                    
                    print(f"{dataset} & {repr_type} & {gd_variant} & {best_lambda} & "
                          f"{accuracy} & {precision} & {recall} & {f1} \\\\")
    
    print(r"\hline")
    print(r"\end{tabular}")
    print(r"\end{table}")


def format_nb_results_table(results_file: str):
    """
    Format Naive Bayes results into a nice table for the report.
    
    Args:
        results_file: Path to naive bayes results file
    """
    print("\n" + "="*100)
    print("NAIVE BAYES RESULTS TABLE")
    print("="*100)
    
    if not os.path.exists(results_file):
        print(f"Error: {results_file} not found")
        return
    
    with open(results_file, 'r', encoding='utf-8') as f:
        content = f.read()
        print(content)
    
    print("\nLaTeX Table Format:")
    print("-"*100)
    print(r"\begin{table}[h]")
    print(r"\centering")
    print(r"\caption{Naive Bayes Results}")
    print(r"\begin{tabular}{|l|l|c|c|c|c|}")
    print(r"\hline")
    print(r"Dataset & NB Variant & Accuracy & Precision & Recall & F1 \\")
    print(r"\hline")
    
    # Parse and format each result
    with open(results_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        for line in lines[3:]:  # Skip header lines
            if line.strip() and not line.startswith('-'):
                parts = line.split()
                if len(parts) >= 6:
                    dataset = parts[0]
                    # NB variant might be multi-word
                    if "Multinomial" in line:
                        nb_variant = "Multinomial (BoW)"
                    else:
                        nb_variant = "Bernoulli"
                    
                    accuracy = parts[-4]
                    precision = parts[-3]
                    recall = parts[-2]
                    f1 = parts[-1]
                    
                    print(f"{dataset} & {nb_variant} & {accuracy} & {precision} & {recall} & {f1} \\\\")
    
    print(r"\hline")
    print(r"\end{tabular}")
    print(r"\end{table}")


def generate_comparison_summary(lr_file: str, nb_file: str):
    """
    Generate a comparison summary of best performing models.
    
    Args:
        lr_file: Logistic regression results file
        nb_file: Naive Bayes results file
    """
    print("\n" + "="*100)
    print("MODEL COMPARISON SUMMARY")
    print("="*100)
    
    best_models = {}
    
    # Parse LR results
    if os.path.exists(lr_file):
        with open(lr_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            for line in lines[3:]:
                if line.strip() and not line.startswith('-'):
                    parts = line.split()
                    if len(parts) >= 8:
                        dataset = parts[0]
                        repr_type = parts[1]
                        gd_variant = parts[2]
                        f1 = float(parts[-1])
                        
                        key = f"{dataset}_{repr_type}"
                        if key not in best_models or f1 > best_models[key]['f1']:
                            best_models[key] = {
                                'model': f"LR-{gd_variant}",
                                'f1': f1,
                                'accuracy': float(parts[-4])
                            }
    
    # Parse NB results
    if os.path.exists(nb_file):
        with open(nb_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            for line in lines[3:]:
                if line.strip() and not line.startswith('-'):
                    parts = line.split()
                    if len(parts) >= 6:
                        dataset = parts[0]
                        if "Multinomial" in line:
                            nb_variant = "Multinomial-NB"
                            repr_type = "Bow"
                        else:
                            nb_variant = "Bernoulli-NB"
                            repr_type = "Bernoulli"
                        
                        f1 = float(parts[-1])
                        
                        key = f"{dataset}_{repr_type}"
                        if key not in best_models or f1 > best_models[key]['f1']:
                            best_models[key] = {
                                'model': nb_variant,
                                'f1': f1,
                                'accuracy': float(parts[-4])
                            }
    
    # Print summary
    print("\nBest Model for Each Dataset/Representation:")
    print("-"*80)
    for key in sorted(best_models.keys()):
        dataset, repr_type = key.split('_')
        model_info = best_models[key]
        print(f"{dataset.upper():8} {repr_type.capitalize():10} -> "
              f"{model_info['model']:15} (F1={model_info['f1']:.4f}, Acc={model_info['accuracy']:.4f})")
    
    # Overall best
    overall_best = max(best_models.items(), key=lambda x: x[1]['f1'])
    print("\n" + "="*80)
    print("OVERALL BEST MODEL:")
    print(f"  Configuration: {overall_best[0]}")
    print(f"  Model: {overall_best[1]['model']}")
    print(f"  F1 Score: {overall_best[1]['f1']:.4f}")
    print(f"  Accuracy: {overall_best[1]['accuracy']:.4f}")
    print("="*80)


def generate_analysis_questions_template():
    """
    Generate a template for answering the required analysis questions.
    """
    print("\n" + "="*100)
    print("ANALYSIS QUESTIONS TEMPLATE")
    print("="*100)
    
    questions = [
        ("1. Did Naive Bayes or Logistic Regression perform better? Why?",
         """
         Consider:
         - Overall F1 scores across all datasets
         - Consistency of performance
         - Training time differences
         - Theoretical advantages of each approach
         - Dataset characteristics (sparse features, class imbalance, etc.)
         """),
        
        ("2. Which combination of algorithm and data representation yielded the best performance? Why?",
         """
         Examine:
         - Best F1 scores for each combination
         - BoW vs Bernoulli for each algorithm
         - Why certain representations work better with certain algorithms
         - Connection to algorithm assumptions (e.g., NB independence assumption)
         """),
        
        ("3. Did Multinomial Naive Bayes perform better than Logistic Regression on the Bag of Words representation? Explain.",
         """
         Compare:
         - Multinomial NB vs best LR (BoW) for each dataset
         - Statistical significance of differences
         - When/why one might outperform the other
         - Generative vs discriminative modeling trade-offs
         """),
        
        ("4. Did Bernoulli Naive Bayes perform better than Logistic Regression on the Bernoulli representation? Explain.",
         """
         Compare:
         - Bernoulli NB vs best LR (Bernoulli) for each dataset
         - Binary feature assumptions
         - Model complexity and overfitting
         - Computational efficiency
         """),
        
        ("5. Which variant of gradient descent was better in terms of speed and/or accuracy when learning logistic regression classifiers?",
         """
         Analyze:
         - Training time for each variant
         - Final accuracy/F1 scores
         - Convergence behavior
         - Trade-offs between speed and performance
         - Recommendations for future use
         """)
    ]
    
    for question, guidance in questions:
        print(f"\n{question}")
        print("-"*100)
        print("Guidance:")
        print(guidance)
        print("Your Answer:")
        print("[Write your detailed analysis here based on experimental results]")
        print()


def main():
    """
    Main function to generate all formatted results.
    """
    results_dir = "./results"
    lr_file = os.path.join(results_dir, "logistic_regression_results.txt")
    nb_file = os.path.join(results_dir, "naive_bayes_results.txt")
    
    print("CS 4375 PROJECT 1 - RESULTS FORMATTER")
    
    # Format results tables
    format_lr_results_table(lr_file)
    format_nb_results_table(nb_file)
    
    # Generate comparison summary
    generate_comparison_summary(lr_file, nb_file)
    
    # Generate analysis template
    generate_analysis_questions_template()
    
    print("\n" + "="*100)
    print("Use the formatted tables and LaTeX code above in your report!")
    print("="*100)


if __name__ == "__main__":
    main()